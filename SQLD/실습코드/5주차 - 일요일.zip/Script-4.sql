-- 서브 쿼리
SELECT first_name
FROM employees e
WHERE department_id = (SELECT department_id
					   FROM employees
					   WHERE first_name = 'Donald');	

-- 서브 쿼리의 종류
--	> 일반 서브쿼리 or WHERE 서브쿼리 : 조건에 있는 서브쿼리
--	> 스칼라 서브쿼리 : SELECT절, 컬럼쪽에 서브쿼리가 들어가는 형태
--  > 인라인 뷰 : FROM절, 테이블 대신 서브쿼리가 들어가는 형태

-------------------------------------------------------------------
-- 평균 급여보다 높은 직원의 이름을 조회하세요.
SELECT first_name
FROM employees
WHERE salary > (SELECT avg(salary) FROM employees);

-- 1. 단일행 서브쿼리
--	> 결과값의 데이터(행)가 1개인 서브쿼리
--	> 단일행 비교 연산자와 함께 사용 가능 (>, >=, <, <=, =, !=, <>)
SELECT first_name, last_name
FROM employees
WHERE salary >= (SELECT avg(salary) FROM employees
				 WHERE department_id = 30);

-- 가장 높은 월급을 받는 직원의 이름 조회
--	> salary가 높은 월급과 같을 때
SELECT first_name
FROM EMPLOYEES e 
WHERE salary = (SELECT max(salary) FROM employees);

-- 2. 다중행 서브쿼리
--	> 결과 값의 데이터(행)가 여러개인 서브쿼리
--	> 다중행 비교 연산자와 사용 (IN, ALL, ANY)

-- IN : 여러 값중 하나라도 일치(=)하면 TRUE
SELECT first_name, department_id
FROM employees
WHERE department_id IN (SELECT department_id FROM departments);


-- ANY : 조건이 하나라도 만족하면 TRUE
--	> 사용되는 연산자 : >, >=, <, <=
--	> 숫자를 비교할 때 사용하면 최솟값(>)
SELECT first_name, salary
FROM employees
WHERE salary > ANY (SELECT salary FROM employees
					WHERE department_id = 30);

-- ALL : 모든 값을 만족하면 TRUE
--	> 사용되는 연산자 : >, >=, <, <=
--	> 숫자를 비교할 때 사용하면 최댓값(>)
SELECT first_name, salary
FROM employees
WHERE salary > ALL (SELECT salary FROM employees
					WHERE department_id = 30);

-- 3. 다중열 다중행 서브쿼리
--	> 다중열 : 컬럼(열)이 2개 이상
--	> 다중행 : 조회된 결과(행)가 2개 이상

-- 서브쿼리에 있는 SELECT의 컬럼이 1개 = 단일열
-- 서브쿼리에 있는 SELECT의 컬럼이 2개 이상 = 다중열

-- 단일행 비교 연산자(>, >=, <, <=, ...)가 사용됐다 = 단일행
-- 다중행 비교 연산자(IN, ALL, ANY)가 사용됐다 = 단일행 or 다중행
SELECT first_name, department_id, job_id
FROM employees
WHERE (department_id, job_id) IN (SELECT department_id, job_id
								  FROM job_history);

------------------------------------------------

-- 상관 서브쿼리
--  > 외부 쿼리 값을 내부에서 사용
--  > 외부 테이블의 값을 참조하기 때문에 성능 이슈가 발생할 수 있다
SELECT first_name, salary, department_id
FROM employees e
WHERE salary > (SELECT avg(salary)
				FROM employees e2
				WHERE e.department_id = e2.department_id);


-- EXISTS랑도 서브쿼리가 자주 사용됨
--	> EXISTS : 존재 여부 확인 (존재하면 TRUE)
SELECT first_name
FROM employees e
WHERE EXISTS (SELECT 1
			  FROM job_history j
			  WHERE e.EMPLOYEE_ID = j.EMPLOYEE_ID);

-----------------------------------------------------------
-- 스칼라 서브쿼리
--	- SELECT절에 사용
--	- 컬럼 이름 대신 서브쿼리가 들어감
SELECT first_name, 
	  (SELECT department_name
	   FROM departments d
	   WHERE d.department_id = e.department_id) AS department_name
FROM employees e;
--------------------------------------------------
-- 인라인 뷰
--	- FROM 절에서 서브쿼리를 사용하는 방식
--	- 임시 테이블 역할
--	- 집계 쿼리를 작성할 때 주로 사용
--		> 인라인뷰에서 걸러진 임시 테이블의 데이터를 집계하기 때문에
--		  전체 테이블의 데이터에서 집계하는 것보다 성능이 좋음
--	- 오라클에서는 TOP-N 쿼리를 작성할 때 주로 사용 (ROWNUM)
SELECT department_id, avg_salary
FROM (SELECT department_id, avg(salary) AS avg_salary
	  FROM employees
	  GROUP BY department_id)
WHERE avg_salary >= 7000;

-- 직원의 부서 번호, 평균 월급을 구하고 (인라인뷰)
-- 최종적으로 부서명과 평균 월급을 조회하라.
SELECT department_name, avg_salary
FROM (SELECT department_id, avg(salary) AS avg_salary
	  FROM employees
	  GROUP BY department_id) t
JOIN departments d
ON t.DEPARTMENT_ID = d.DEPARTMENT_ID ;

-- 인라인뷰에서 department_id 별 직원 수 조회 (employees 테이블)
-- 최종적으로 department_id와 직원 수를 출력
--	> 조건 : 직원수가 5명 이상
SELECT department_id, cnt
FROM (SELECT department_id, COUNT(*) AS cnt
	  FROM employees
	  GROUP BY department_id)
WHERE cnt >= 5;

-- 직원별 수 Top 3
--	- 오라클에서 ROWNUM을 사용할 때 인라인뷰를 사용하게 되는데
--	  정렬(OREDR BY) 전에 짜르기 때문에 주의가 필요함
--		> ROWNUM은 반드시 정렬(ORDER BY) 후 사용
SELECT *
FROM (SELECT department_id, COUNT(*) AS cnt
	  FROM employees
	  GROUP BY department_id
	  ORDER BY cnt DESC)
WHERE rownum <= 3;

-- 잘못된 ROWNUM
SELECT *
FROM employees
WHERE ROWNUM <= 2
ORDER BY salary DESC;

-- 올바른 ROWNUM
SELECT *
FROM (SELECT *
	  FROM employees
	  ORDER BY salary DESC)
WHERE ROWNUM <= 2;















