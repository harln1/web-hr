SELECT employee_id,
	   first_name || '  ' || last_name AS full_name
FROM employees;

-------------------------------------
-- 1. 문자 함수

-- 1-1. UPPER
--	> 문자를 대문자로 변환한다.
SELECT upper(last_name) FROM employees;

-- 1-2. LOWER
--	> 문자를 소문자로 변환한다.
SELECT lower(last_name) FROM employees;

-- 1-3. INITCAP
--	> 첫 글자를 대문자로, 나머지는 소문자로 변환
SELECT initcap(last_name) FROM employees;

-- 1.4 CONCAT (가끔 보임)
--	> 문자열을 이어붙여주는 함수(||와 동일한 기능)
--	> ||는 Oracle에서 지원해주는 문법
SELECT concat(first_name, last_name) FROM employees;

-- 1.5 SUBSTR  (꽤 자주 출제됨)
--	> 문자열의 일부를 잘라내는 함수
SELECT substr(phone_number, 1, 3) FROM employees;

-- 1.6 LENGTH 
--	> 문자열의 길이를 알려주는 함수
SELECT length(last_name) FROM employees;

-- 1.7 INSTR
--	> 찾는 문자열이 처음 나타나는 위치를 반환해주는 함수
--	> 없으면 0을 반환
SELECT instr(email, 'A') FROM employees;

-- 1.8 LPAD
--	> 왼쪽을 특정 문자로 채워서 길이를 맞춰주는 함수
--	> RPAD는 오른쪽을 채워줌
SELECT lpad(employee_id, 6, '1') FROM employees;

-- 1.9 TRIM / LTRIM / RTRIM
--	> 공백 또는 특정 문자 제거
SELECT trim('    SQLD  ') FROM dual;
SELECT ltrim('xxSQLDxxx', 'x') FROM dual;
SELECT rtrim('xxSQLDxxx', 'x') FROM dual;

-- 1.10 REPLACE
--	> 특정 문자열을 다른 문자열로 바꿔주는 함수
SELECT replace(phone_number, '.', '-') FROM employees;

-- 1.11 TRANSLATE
--	> 문자 단위로 치환해주는 함수
SELECT translate('ABC-123', 'ABC-3', 'abc_') FROM dual;

---------------------------------------------------
-- 2. 숫자 함수

-- 2-1. ROUND (출제 빈도 높음)
--	> 지정한 자리에서 반올림해주는 함수
SELECT round(salary/12, 2) FROM employees;

-- 2-2. TRUNC (출제 빈도 높음)
--	> 지정한 자리에서 소수점을 버림 해주는 함수
SELECT trunc(salary/12, 2) FROM employees;

-- 2-3. CEIL
--	> 올림 함수

-- 2-4. FLOOR
--	> 내림 함수

-- 2-5. MOD
--	> 나머지를 구하는 함수
---------------------------------------------------
-- 3. 날짜 함수

-- 3-1. SYSDATE
--	> 날짜와 시간을 반환
SELECT sysdate FROM dual;
SELECT current_date FROM dual;

-- 3.2 ADD_MONTHS
--	> 날짜에 개월 수를 더해주는 함수
SELECT add_months(hire_date, 6) FROM employees;

-- 3.3 MONTHS_BETWEEN
--	> 두 날짜 사이의 개월수 반환
SELECT months_between(sysdate, hire_date) FROM employees;

-- 3.4 LAST_DAY
--	> 해당 월의 마지막 날짜를 반환
SELECT last_day(sysdate) FROM dual;
-----------------------------------------
-- 4. 변환 함수 (문제에 출제 매우 자주됨)

-- 4-1. TO_CHAR (출제 빈도 높음)
--	> 날짜나 숫자를 원하는 형식의 문자로 변환
--	> 99999 -> '99999'
SELECT to_char(salary, '9,999') FROM employees;
SELECT to_char(hire_date, 'YYYY-MM-DD') FROM employees;

-- 4.2 TO_DATE
--	> 문자를 날짜로 변환

-- 4.3 TO_NUMBER
--	> 문자를 숫자로 변환
-----------------------------------------------
-- 5. NULL 처리 함수 (**************)

-- 5-1. NVL
--	> 첫 번째 값이 NULL이면 두번째 값을 반환하고
--	  NULL이 아니면 첫 번째 값을 반환
SELECT salary + NVL(commission_pct * salary, 0)
FROM employees;

-- 5-2. NVL2
--	> 첫 번째 값이 NULL이 아니면 두번째 값
--	  NULL이면 세번째 값을 반환
SELECT nvl2(commission_pct, 'COMMISSION', 'NO_COMMISION')
FROM employees;

-- 5-3. COALESCE
--	> 인자 중 왼쪽부터 첫 번째 NULL이 아닌 값을 반환
SELECT COALESCE(phone_number, email, 'NO_CONTACT')
FROM employees;

-- 5-4. NULLIF
--	> 두 값이 같으면 NULL, 다르면 첫 번째 값 반환
SELECT nullif(commission_pct, 0.1)
FROM EMPLOYEES e 
WHERE commission_pct IS NOT NULL;
-----------------------------------------------
-- 6. 조건 함수 (***********)

-- 6-1. CASE
--	> 조건에 따라 다른 값을 반환하는 SQL 조건식
SELECT CASE	
		 WHEN salary >= 15000 THEN 'HIGH'
		 WHEN salary >= 8000  THEN 'MIDDLE'
		 ELSE 'LOW' -- ELSE는 그 외 나머지의 경우(조건을 안봄)
	   END
FROM employees;

-- 6-2. DECODE
--	> 값 비교에 따라서 다른 값을 반환하는 조건 함수
--	> DECODE(expr, 비교값1, 결과1, 비교값2, 결과2, 기본값)
SELECT decode(job_id,
			  'IT_PROG', 'IT 개발자',
			  'SA_REP', '영업 담당',
			  '기타')
FROM employees;
---------------------------------------------
-- 7. 집계 함수 (************)

-- 7-1. COUNT(*)
--	> 컬럼 값의 NULL 여부와 관계 없이 행의 수를 반환
--  > COUNT(DISTINCT 컬럼) : NULL을 제외한 행의 수 (중복 제거)

-- 7-2. 그 외 나머지
--	> SUM, AVG, MIN, MAX
------------------------------------------
-- 32p ~ 42p (1번 ~ 20번)
-- 쉬는 시간 포함해서 11시 10분까지

-- 1번 : 4
-- 2번 : 1
-- 3번 : 3
-- 4번 : 3
-- 5번 : 1
-- 6번 : 2
-- 7번 : 1
-- 8번 : 3
-- 9번 : 3
-- 10번 : 1
-- 11번 : 4
-- 12번 : 4
-- 13번 : 4
-- 14번 : 4
-- 15번 : 3
-- 16번 : 3
-- 17번 : 2
-- 18번 : 4
-- 19번 : 2
-- 20번 : 1

-- 2과목(32p ~ 130p)
--	> 특히 어려웟던거, 못푼거, 이해가 안되는 문제 
-- 과목 III는 SQLD 범위 아님

-- 2과목
--  > 노랭이 계속 풀어보기
--	> 필요한 함수들 암기

-- 1과목
--	> 개념
-- 엔터티, 인스턴스, 속성, 속성 값

-- 엔터티 : 테이블
-- 인스턴스(튜플) : 데이터 한 줄
-- 속성 : 컬럼
-- 속성 값 : 컬럼에 들어가는 데이터 하나 

SELECT * FROM employees;














