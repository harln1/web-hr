-- INSERT
--	> 테이블에 새로운 데이터를 추가하는 구문
--	> 문법 1) INSERT INTO 테이블명 VALUES (값1, 값2, ....)
--		>> 전체 컬럼에 값을 다 넣을 때
--	> 문법 2) INSERT INTO 테이블명(컬럼1, 컬럼2, ...) AVLUES (값1, 값2, ...);
--		>> 일부 컬럼의 값만 넣을 때 컬럼명 지정

-- 주의해야할 점
--	> 테이블에 정의된 컬럼의 순서, 데이터 타입에 맞게 넣어야 함
--	> NOT NULL 컬럼은 반드시 값을 넣어야 함

-- 문법 1버전 (모든 값을 다 넣는 상황)
INSERT INTO employees
VALUES (employees_seq.nextval,
		'재섭',
		'김',
		'islandtim@naver.com',
		'010-1234-1234',
		sysdate,
		'IT_PROG',
		10000,
		0.5,
		NULL,
		60);

SELECT * FROM employees WHERE last_name = '김';


-- 문법 2버전 (최소한의 정보만 ISNERT)
--	> 값을 넣을 컬럼명을 지정
--	> NOT NULL은 반드시 값을 넣어줘야 함
--	> 값을 넣지 않은 컬럼들은 NULL로 들어감
INSERT INTO employees(employee_id,
					  last_name,
					  email,
					  hire_date,
					  job_id,
					  salary)
VALUES (employees_seq.nextval,
		'test@test.com',
		'JUNG',
		sysdate,
		'IT_PROG',
		10000);

SELECT * FROM employees WHERE email='test@test.com';
--문제 1. 신규 직원 등록
-- - employee_id: 300
-- - first_name: JAMES
-- - last_name: KIM
-- - email: JAMESK
-- - phone_number: 010-1234-5678
-- - hire_date: 오늘 날짜
-- - job_id: IT_PROG
-- - salary: 6000
-- - commission_pct: NULL
-- - manager_id: 103
-- - department_id: 60
INSERT INTO employees
VALUES (300,
		'JAMES',
		'KIM',
		'JAMESK',
		'010-1234-5678',
		sysdate,
		'IT_PROG',
		6000,
		NULL,
		103,
		60);
--------------------------------------------------------------------------
--문제 2. 부서 포함 직원 등록
-- - employee_id: 307
-- - last_name: LIM
-- - email: LIML
-- - hire_date: 오늘 날짜
-- - job_id: HR_REP
-- - department_id: 40
INSERT INTO employees(employee_id,
					  last_name,
					  email,
					  hire_date,
					  job_id,
					  department_id)
VALUES (307,
		'LIM',
		'LIML',
		sysdate,
		'HR_REP',
		40);
				

-----------------------------------------------------------------
-- UPDATE
--	> 데이터를 변경하는 구문 
--	> 문법 : UPDATE 테이블명 SET 컬럼1=값1, 컬럼2=값, ...

-- 주의해야할점
--	> 조건을 주지 않으면 테이블의 전체 데이터가 변경되기 때문에
--	  의도하지 않은 상황이라면 무조건 조건(WHERE)을 주어야 함
UPDATE employees
SET last_name='이',
    first_name='길동'
WHERE employee_id = 207;

SELECT * FROM employees WHERE employee_id = 207;


-- EMPLOYEES 테이블의 Donald 직원의 데이터를 변경하라.
--	> email : 'donald@test.com'
--	> phone_number : 01012341234
--	> commission_pct : 0.7
SELECT * FROM employees WHERE first_name='Donald';
UPDATE employees
SET email='donald@test.com',
    phone_number='01012341234',
    commission_pct=10.8
WHERE employee_id = 198;
----------------------------------------------------------
-- DELETE
--	> 기존 데이터를 삭제하는 구문
--	> 문법 : DELETE FROM 테이블명
--	> DELETEL도 마찬가지로 조건을 반드시 주어야 한다.
--		>> 조건을 주지 않으면 테이블의 전체 데이터가 삭제됨
DELETE FROM employees
WHERE employee_id = 207;

SELECT * FROM employees WHERE employee_id = 207;






















