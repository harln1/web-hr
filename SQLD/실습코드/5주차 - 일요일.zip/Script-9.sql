CREATE TABLE tcl_tb (
	value varchar2(50)
);

INSERT INTO tcl_tb values('1');
INSERT INTO tcl_tb values('2');
INSERT INTO tcl_tb values('3');
COMMIT;

SELECT * FROM tcl_tb;

-- TCL
--	- 트랜잭션을 제어하는 언어
--	- 트랜잭션 : 데이터베이스에서 실행되는 논리적 작업 단위(DML)

-- 트랜잭션의 특징 ACID
--	- Automicity (원자성)
--		> 트랜잭션이 모두 반영이 되던지, 모두 반영되지 않던지 해야한다.
--		> 트랜잭션의 모든 작업은 반드시 성공해야 하며
--		  하나라도 에러가 발생할 경우 모든 작업이 취소되어야 한다.
--	- Consistency (일관성)
--		> 트랜잭션의 처리 결과는 항상 일관성을 만족해야 한다.
--		> 모든 무결성 제약 조건을 만족해야 한다.
--	- Isolation (독립성)
--		> 트랜잭션이 실행중일 경우 다른 트랜잭션이 끼어들어서는 안된다.
--	- Durability (지속성)
--		> 트랜잭션이 성공했다면 모든 결과는 영구적으로 반영이 되어야 한다.

-- COMMIT
--	- 트랜잭션을 데이터베이스 반영하는 작업
INSERT INTO tcl_tb values('1');
INSERT INTO tcl_tb values('2');
INSERT INTO tcl_tb values('3');
COMMIT;

-- ROLLBACK
--	- 현재 트랜잭션을 데이터베이스에 반영하지 않음
--		> 마지막 COMMIT 시점으로 되돌아감
INSERT INTO tcl_tb values('4');

UPDATE tcl_tb
SET value = 'update_value'
WHERE value = '3';

DELETE FROM tcl_tb;

ROLLBACK;

SELECT * FROM tcl_tb;











