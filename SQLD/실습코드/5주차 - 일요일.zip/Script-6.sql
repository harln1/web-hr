-- DDL
--	> 데이터베이스의 객체(오브젝트)를 생성/수정/삭제하는 언어

-- DDL의 종류
--	> CREATE : 객체 생성
--	> ALTER : 객체 수정
--	> DROP : 객체 삭제

----------------------------------------------
-- CREATE와 제약조건

-- 제약 조건 
--	> 컬럼에 어떠한 조건을 걸어서 부적절한 데이터가 추가되는걸 방지함

-- 1. NOT NULL
--	> NULL이 들어올 수 없다.

-- 2. UNIQUE 
--	> 반드시 유일해야하는 값 (중복이 절대 되어선 안됨)

-- 3. CHECK
--	> 해당 컬럼에 들어와야 할 값들을 미리 정함

-- 4. DEFAULT
--	> 기본 값 설정
CREATE TABLE users (
	user_id varchar2(30) NOT NULL UNIQUE ,
	password varchar2(255),
	gender varchar2(1) CHECK (gender IN ('M', 'W')),
	in_date DATE DEFAULT sysdate
);

INSERT INTO users VALUES('test', 'qwer1234!', 'W');
INSERT INTO users VALUES('test', '123456789');
SELECT * FROM users;

DROP TABLE users;

---------------------------------------------------
-- 5. PRIMARY KEY (기본키, PK)
--	> 튜플을 유일하게 식별할 수 있는 식별자의 역할을 수행
--	> 해당 컬럼은 반드시 유일(UNIQUE)해야 하고 
--    NULL이 들어올 수 없음(NOT NULL)
CREATE TABLE users (
	user_id 	NUMBER PRIMARY KEY,
	id 			varchar2(30) NOT NULL UNIQUE,
	password 	varchar2(255) NOT NULL,
	gender 		varchar2(1) CHECK (gender IN ('M', 'W')),
	in_date		DATE DEFAULT sysdate 
);

INSERT INTO users(user_id, id, password, gender)
VALUES (1, 'test', 'qwer1234', 'M');

SELECT * FROM users;

DROP TABLE users;

-- 6. FOREIGN KEY (외래키, FK)
--	> 다른 테이블을 참조하여 테이블간의 관계를 맺어주는 키
--		1) 기본키 또는 UNIQUE가 정의된 컬럼을 참조하여 가져옴
--		2) 가져온 테이블은 부모 테이블, 외래키가 있는 테이블은 자식 테이블
--		3) 부모 테이블에 존재하는 값만 추가할 수 있음
--		4) 데이터 타입은 반드시 일치해야 함
CREATE TABLE user_jobs (
	job_code NUMBER PRIMARY KEY,
	job_name varchar2(50) NOT NULL 
);

CREATE TABLE users (
	user_id 	NUMBER PRIMARY KEY,
	id 			varchar2(30) NOT NULL UNIQUE,
	password 	varchar2(255) NOT NULL,
	gender 		varchar2(1) CHECK (gender IN ('M', 'W')),
	in_date		DATE DEFAULT sysdate,
	job_code	NUMBER REFERENCES user_jobs(job_code)
);

------------------------------------------------
-- ALTER
--	- 데이터베이스의 객체 구조를 변경해주는 구문
--	- 문법 : ALTER 객체종류 객체명 ...
ALTER TABLE user_jobs RENAME TO test_user_jobs;

ALTER TABLE test_user_jobs MODIFY (
	job_name varchar2(500) 
);

-- 컬럼 이름 변경
ALTER TABLE test_user_jobs
RENAME COLUMN job_name TO test_job_name;

-- 컬럼 추가
ALTER TABLE test_user_jobs ADD (
	jobs_in_date DATE 
);

-- 컬럼에 제약 조건 추가
ALTER TABLE test_user_jobs
ADD CONSTRAINT job_name_unqiue UNIQUE(test_job_name);
--               제약조건 이름    제약조건(컬럼명)

---------------------------------------------------
-- DROP
--	- 데이터베이스의 객체 제거
DROP TABLE test_user_jobs;







