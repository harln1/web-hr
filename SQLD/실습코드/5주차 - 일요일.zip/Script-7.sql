-- DCL
--	- 계정에 권한을 부여하거나 회수하는 역할을 가진 언어

-- GRANT
--	- 권한 부여

ALTER SESSION SET "_ORACLE_SCRIPT"=TRUE;
CREATE USER grant_user IDENTIFIED BY qwer1234;

-- 접속 권한 부여
GRANT CREATE SESSION TO grant_user;

-- 테이블 생성 권한 부여
GRANT CREATE TABLE TO grant_user;

-- grant_user한테 HR의 employees 테이블 SELECT 권한 부여
GRANT SELECT ON hr.employees TO grant_user;

SELECT * FROM hr.employees;
-------------------------------------------------
-- REVOKE
--	- 권한 회수
REVOKE SELECT ON hr.employees FROM grant_user;







