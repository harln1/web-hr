-- 서브 쿼리
SELECT first_name
FROM employees e
WHERE department_id = (SELECT department_id
					   FROM employees
					   WHERE first_name = 'Donald');	

-- 서브 쿼리의 종류
--	> 일반 서브쿼리 or WHERE 서브쿼리 : 조건에 있는 서브쿼리
--	> 스칼라 서브쿼리 : SELECT절, 컬럼쪽에 서브쿼리가 들어가는 형태
--  > 인라인 뷰 : FROM절, 테이블 대신 서브쿼리가 들어가는 형태

-------------------------------------------------------------------
-- 평균 급여보다 높은 직원의 이름을 조회하세요.

SELECT first_name
FROM employees
WHERE salary > (SELECT avg(salary) FROM employees);

-- 1. 단일행 서브쿼리
--	> 결과값의 데이터(행)가 1개인 서브쿼리
--	> 단일행 비교 연산자와 함께 사용 가능 (>, >=, <, <=, =, !=, <>)
SELECT first_name, last_name
FROM employees
WHERE salary >= (SELECT avg(salary) FROM employees
				 WHERE department_id = 30);

-- 가장 높은 월급을 받는 직원의 이름 조회
--	> salary가 높은 월급과 같을 때
SELECT first_name
FROM EMPLOYEES e 
WHERE salary = (SELECT max(salary) FROM employees);

-- 2. 다중행 서브쿼리
--	> 결과 값의 데이터(행)가 여러개인 서브쿼리
--	> 다중행 비교 연산자와 사용 (IN, ALL, ANY)

-- IN : 여러 값중 하나라도 일치(=)하면 TRUE
SELECT first_name, department_id
FROM employees
WHERE department_id IN (SELECT department_id FROM departments);

-- ANY : 조건이 하나라도 만족하면 TRUE
--	> 사용되는 연산자 : >, >=, <, <=
--	> 숫자를 비교할 때 사용하면 최솟값(>)
SELECT first_name, salary
FROM employees
WHERE salary > ANY (SELECT salary FROM employees
					WHERE department_id = 30);

-- ALL : 모든 값을 만족하면 TRUE
--	> 사용되는 연산자 : >, >=, <, <=
--	> 숫자를 비교할 때 사용하면 최댓값(>)
SELECT first_name, salary
FROM employees
WHERE salary > ALL (SELECT salary FROM employees
					WHERE department_id = 30);

-- 3. 다중열 다중행 서브쿼리
--	> 다중열 : 컬럼(열)이 2개 이상
--	> 다중행 : 조회된 결과(행)가 2개 이상

-- 서브쿼리에 있는 SELECT의 컬럼이 1개 = 단일열
-- 서브쿼리에 있는 SELECT의 컬럼이 2개 이상 = 다중열

-- 단일행 비교 연산자(>, >=, <, <=, ...)가 사용됐다 = 단일행
-- 다중행 비교 연산자(IN, ALL, ANY)가 사용됐다 = 단일행 or 다중행
SELECT first_name, department_id, job_id
FROM employees
WHERE (department_id, job_id) IN (SELECT department_id, job_id
								  FROM job_history);

------------------------------------------------

-- 상관 서브쿼리
--  > 외부 쿼리 값을 내부에서 사용
SELECT first_name, salary, department_id
FROM employees e
WHERE salary > (SELECT avg(salary)
				FROM employees e2
				WHERE e.department_id = e2.department_id);













