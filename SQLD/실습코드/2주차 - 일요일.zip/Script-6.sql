-- DDL
--	> 데이터베이스의 객체(오브젝트)를 생성/수정/삭제하는 언어

-- DDL의 종류
--	> CREATE : 객체 생성
--	> ALTER : 객체 수정
--	> DROP : 객체 삭제

----------------------------------------------
-- CREATE와 제약조건

-- 제약 조건 
--	> 컬럼에 어떠한 조건을 걸어서 부적절한 데이터가 추가되는걸 방지함

-- 1. NOT NULL
--	> NULL이 들어올 수 없다.

-- 2. UNIQUE 
--	> 반드시 유일해야하는 값 (중복이 절대 되어선 안됨)

-- 3. CHECK
--	> 해당 컬럼에 들어와야 할 값들을 미리 정함
CREATE TABLE users (
	user_id varchar2(30) NOT NULL UNIQUE ,
	password varchar2(255),
	gender varchar2(1) CHECK (gender IN ('M', 'W'))
);

INSERT INTO users VALUES('test', 'qwer1234!', 'W');
INSERT INTO users VALUES('test', '123456789');
SELECT * FROM users;

DROP TABLE users;
















